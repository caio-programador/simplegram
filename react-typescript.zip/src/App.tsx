import { BrowserRouter, Routes, Route } from 'react-router'
import Navbar from './components/Navbar'
import About from './pages/About'
import CreatePost from './pages/CreatePost'
import Home from './pages/Home'
import Footer from './components/Footer'
import PostDetails from './components/PostDetails'

function App () {
  return (
    
      <BrowserRouter>
        <Navbar/>
        <div data-testid='container' className='container'>
          <Routes>
            <Route path='/' element={<Home/>}/>
            <Route path='/about' element={<About />}/>
            <Route path='/posts/create' element={<CreatePost />} />
            <Route path='/posts/:id' element={<PostDetails />} />
          </Routes>
        </div>
        <Footer/>
      </BrowserRouter>
  )
}

export default App