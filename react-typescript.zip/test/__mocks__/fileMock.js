module.exports = {
  __esModule: true,
  default: 'test-file-stub',
};