export default interface IPost {
  id?: string
  title: string
  description: string
  imageURL: string
}