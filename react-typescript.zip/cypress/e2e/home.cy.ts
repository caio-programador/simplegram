describe("Home Page", () => {
  beforeEach(() => {
    cy.visit("/")
  })

  it("should have a logo and navbar", () => {
    cy.get('[href="/"]').should('be.visible')
    cy.get('[href="/about"]').should('be.visible')
    cy.get('[href="/posts/create"]').should('be.visible')

    cy.get('._logo_1hlt4_19 > a').should('be.visible')
  })

  it("should habe at least one post", () => {
    cy.get('._post_vqv34_1').should('have.length.at.least', 1)
  })

  it("should click a post and show more details", () => {
    cy.get(':nth-child(1) > .btn').click()

    cy.get('h2').should('be.visible')
  })

  it("should return to home page", () => {
    cy.get(':nth-child(1) > .btn').click()
    cy.get('._logo_1hlt4_19 > a').click()
      .then( () => cy.url().should('equal', Cypress.config('baseUrl')+'/')
    )
  })
})