import { render, screen } from "@testing-library/react"
import Home from "../../pages/Home"
import { useQuery } from "@tanstack/react-query"
import IPost from "../../interfaces/Post"
import { MemoryRouter } from "react-router"


jest.mock('@tanstack/react-query', () => ({
  ...jest.requireActual('@tanstack/react-query'),
  useQuery: jest.fn()
}))

describe("Home Component", () => {

  beforeEach(() => {
    jest.clearAllMocks()
  })

  it("Should render correctly",  () => {
    (useQuery as jest.Mock).mockImplementation(() => ({
      data: [], error: null, isLoading: false
    }))
    render(<Home/>)

  })

  it("Should render a loading message", () => {
    (useQuery as jest.Mock).mockImplementation(() => ({
      data: null, error: null, isLoading: true
    }))

    render(<Home/>)

    const el = screen.getByText("Carregando...")
    expect(el).toBeInTheDocument()
  })

  it("Should render a error message", () => {
    (useQuery as jest.Mock).mockImplementation(() => ({
      data: null, error: true, isLoading: false
    }))

    render(<Home/>)

    const el = screen.getByText("Um erro ocorreu ao carregar os posts! Tente novamente mais tarde")
    expect(el).toBeInTheDocument()
  })

  it("should render posts", () => {
    (useQuery as jest.Mock).mockImplementation(() => ({
      data: [
        { 
          id: '1',
          title: 'Post 1',
          description: 'string',
          imageURL: 'string'
        },
        {
          id: '2',
          title: 'Post 2',
          description: 'string',
          imageURL: 'string'
        }
      ] as IPost[], error: null, isLoading: false
    }));
    
    render(
      <MemoryRouter>
        <Home />
      </MemoryRouter>
    )

    const post1 = screen.getByText("Post 1")
    expect(post1).toBeInTheDocument()
    const post2 = screen.getByText("Post 2")
    expect(post2).toBeInTheDocument()
  })
})